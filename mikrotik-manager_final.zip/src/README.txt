Panduan penggunaan Mikrotik Manager dengan Docker dan Nginx/Apache.

1. Jalankan dengan Docker:
   docker-compose up -d

2. Akses di browser:
   http://localhost:8080

3. Struktur file:
   - src/: semua file web
   - data/: data router, log
   - assets/: CSS, JS, icon

4. Login default:
   user: jrin37
   pass: 1234
